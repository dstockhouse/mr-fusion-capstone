#ifndef CUTE_REPORTER_HEADER
#define CUTE_REPORTER_HEADER

#include <cgreen/reporter.h>

#ifdef __cplusplus
extern "C" {
#endif

extern TestReporter *create_cute_reporter(void);

#ifdef __cplusplus
}
#endif

#endif

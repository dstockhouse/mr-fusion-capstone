#ifndef STRINGIFY_TOKEN_HEADER
#define STRINGIFY_TOKEN_HEADER

#define STRINGIFY_TOKEN(token) #token

#endif


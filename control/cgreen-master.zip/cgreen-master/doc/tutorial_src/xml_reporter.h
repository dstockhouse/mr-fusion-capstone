#ifndef _XML_REPORTER_HEADER_
#define _XML_REPORTER_HEADER_

#include <cgreen/reporter.h>

TestReporter *create_xml_reporter();

#endif
